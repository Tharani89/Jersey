package com.mastercard.codetest.jerseystore.controller;

import com.mastercard.codetest.jerseystore.service.SalesService;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class SalesController {
	
	private static final Logger LOGGER = LoggerFactory.getLogger(SalesController.class); 

	private final SalesService salesService;

	@Autowired
	public SalesController(SalesService salesService) {
		this.salesService = salesService;
	}

	@GetMapping(value = "/rest/api/v1/sale")
	public ResponseEntity<Integer> makeSale() {
		LOGGER.info("Calling makeSale controller: ");
		final int totalSales = salesService.addSale(100);
		return new ResponseEntity<>(totalSales, HttpStatus.CREATED);
	}

}
