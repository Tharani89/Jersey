package com.mastercard.codetest.jerseystore.service;

import java.util.List;

import com.mastercard.codetest.jerseystore.exception.JerseyException;
import com.mastercard.codetest.jerseystore.model.Jersey;

public interface IJerseyStoreService {

	public Jersey getJersey(String shirtId) throws JerseyException;
	
	public List<Jersey> getAllJerseys() throws JerseyException;
	
	public boolean addJersey(List<Jersey> jerseyList) throws JerseyException;
}
