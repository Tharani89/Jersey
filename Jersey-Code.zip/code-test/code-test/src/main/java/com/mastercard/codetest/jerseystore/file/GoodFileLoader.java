package com.mastercard.codetest.jerseystore.file;

import java.io.FileReader;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.mastercard.codetest.jerseystore.model.Jersey;
import com.mastercard.codetest.jerseystore.model.JerseyCut;
import com.mastercard.codetest.jerseystore.model.JerseyMaterial;
import com.mastercard.codetest.jerseystore.model.JerseySize;
import com.mastercard.codetest.jerseystore.model.JerseyType;
import com.mastercard.codetest.jerseystore.service.JerseyStoreService;
import com.opencsv.CSVReader;

@Component("goodFileLoader")
public class GoodFileLoader extends FileLoader {

	private static final Logger LOGGER = LoggerFactory.getLogger(GoodFileLoader.class);

	private JerseyStoreService jerseyStoreService;

	@Autowired
	public GoodFileLoader(JerseyStoreService jerseyStoreService) {
		this.jerseyStoreService = jerseyStoreService;
	}

	@Override
	public void load(String path) {
		LOGGER.debug("Loading CSV File:");
		CSVReader csvReader = null;
		try {
			csvReader = new CSVReader(new FileReader(path));
			String[] jerseyDetails = null;
			// Create List for holding Jersey objects
			List<Jersey> jerseyList = new ArrayList<Jersey>();

			while ((jerseyDetails = csvReader.readNext()) != null) {
				Jersey jersey = new Jersey(UUID.randomUUID().toString(), JerseySize.valueOf(jerseyDetails[0]),
						jerseyDetails[1], jerseyDetails[2], jerseyDetails[3], JerseyType.valueOf(jerseyDetails[4]),
						JerseyCut.valueOf(jerseyDetails[5]), JerseyMaterial.value(jerseyDetails[6]));
				jerseyList.add(jersey);
			}
			jerseyStoreService.addJersey(jerseyList);
		} catch (Exception ee) {
			ee.printStackTrace();
		} finally {
			try {
				csvReader.close();
			} catch (Exception e) {
				e.getStackTrace();
			}
		}
	}
}
