package com.mastercard.codetest.jerseystore.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.mastercard.codetest.jerseystore.dao.JerseyStoreDaoImpl;
import com.mastercard.codetest.jerseystore.exception.JerseyException;
import com.mastercard.codetest.jerseystore.model.Jersey;

@Service
public class JerseyStoreService implements IJerseyStoreService{

    private JerseyStoreDaoImpl jerseyStoreDao;

    @Autowired
    public JerseyStoreService(JerseyStoreDaoImpl jerseyStoreDao) {
        this.jerseyStoreDao = jerseyStoreDao;
    }
    
	@Override
	public Jersey getJersey(String shirtId) throws JerseyException {
		return jerseyStoreDao.getJersey(shirtId);
	}

	@Override
	public List<Jersey> getAllJerseys() throws JerseyException {
		return jerseyStoreDao.getAllJerseys();
	}

	@Override
	public boolean addJersey(List<Jersey> jerseyList) throws JerseyException {
		return jerseyStoreDao.addJersey(jerseyList);
	}
}	
