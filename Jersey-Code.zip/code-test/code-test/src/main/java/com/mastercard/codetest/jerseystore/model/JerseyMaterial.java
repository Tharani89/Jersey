package com.mastercard.codetest.jerseystore.model;

import static java.util.Arrays.stream;
import static java.util.stream.Collectors.toMap;

import java.util.Map;

public enum JerseyMaterial {
	COTTON("COTTON"), NYLON("NYLON");
	
	private final static Map<String, JerseyMaterial> map =
            stream(JerseyMaterial.values()).collect(toMap(e -> e.getMaterial(), e -> e));
	
	private String material;

	JerseyMaterial(String material) {
		this.material = material;
	}

	public String getMaterial() {
		return material;
	}
	
	public static JerseyMaterial value(String material) {
		 return map.get(material);
	}
	
	/* @Override
	    public String toString() {
	        return this.getMaterial();
	    }

	    public static RandomEnum getEnum(String value) {
	        for(RandomEnum v : values())
	            if(v.getValue().equalsIgnoreCase(value)) return v;
	        throw new IllegalArgumentException();
	    }
*/

}
