package com.mastercard.codetest.jerseystore.dao;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.UUID;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.lang.Nullable;
import org.springframework.stereotype.Component;

import com.mastercard.codetest.jerseystore.constants.QueryConstant;
import com.mastercard.codetest.jerseystore.exception.JerseyException;
import com.mastercard.codetest.jerseystore.model.Jersey;
import com.mastercard.codetest.jerseystore.model.JerseyCut;
import com.mastercard.codetest.jerseystore.model.JerseyMaterial;
import com.mastercard.codetest.jerseystore.model.JerseySize;
import com.mastercard.codetest.jerseystore.model.JerseyType;

@Component
public class JerseyStoreDaoImpl implements IJerseyStoreDao {

	private static final Logger LOGGER = LoggerFactory.getLogger(JerseyStoreDaoImpl.class);

	private JdbcTemplate jdbcTemplate;
	
	@Autowired
	public JerseyStoreDaoImpl(JdbcTemplate jdbcTemplate) {
		this.jdbcTemplate = jdbcTemplate;
	}

	@Override
	public Jersey getJersey(String id) throws JerseyException {
		LOGGER.info("Calling getJersey Method:" +id);
		Jersey jersey = (Jersey) jdbcTemplate.queryForObject(QueryConstant.GET_JERSEY,
                new Object[]{id},
                new RowMapper<Jersey>() {
                    @Nullable
                    @Override
                    public Jersey mapRow(ResultSet resultSet, int i) throws SQLException {
                        Jersey jersey = new Jersey();
                        jersey.setId(resultSet.getString("id"));
                        jersey.setBrand(resultSet.getString("brand"));
                        jersey.setSize(JerseySize.valueOf(resultSet.getInt("size")));
                        jersey.setClub(resultSet.getString("club"));
                        jersey.setYear(resultSet.getString("year"));
                        jersey.setType(JerseyType.valueOf(resultSet.getInt("type")));
                        jersey.setCut(JerseyCut.valueOf(resultSet.getInt("cut")));
                        jersey.setMaterial(JerseyMaterial.value(resultSet.getString("material")));
                        return jersey;
                    }
                });
		return jersey;
	}

	@SuppressWarnings("rawtypes")
	@Override
	public List<Jersey> getAllJerseys() throws JerseyException {
		LOGGER.info("Calling Method:");
		 List<Jersey> jerseys=null;
		 List<Map<String, Object>> rows = jdbcTemplate.queryForList(QueryConstant.ALL_JERSEY);
	       jerseys = new ArrayList<>(rows.size());
	        for(Map row: rows) {
	            Jersey jersey = new Jersey();
	            jersey.setId((String)row.get("id"));
	            jersey.setBrand((String)row.get("brand"));
	            jersey.setSize(JerseySize.valueOf((Integer) row.get("size")));
	            jersey.setClub((String) row.get("club"));
	            jersey.setYear("" + row.get("year"));
	            jersey.setType(JerseyType.valueOf((Integer) row.get("type")));
	            jersey.setCut(JerseyCut.valueOf((Integer) row.get("cut")));
	            jersey.setMaterial(JerseyMaterial.value((String)row.get("material")));
	            jerseys.add(jersey);
	        }
	        return jerseys;
	    }

	@Override
	public boolean addJersey(List<Jersey> jerseyList)  throws JerseyException {
		boolean success = false;
		for(Jersey jersey:jerseyList){
			success = jdbcTemplate.update("INSERT INTO jersey(ID, SIZE, BRAND, CLUB, YEAR, TYPE, CUT, MATERIAL) VALUES (?,?,?,?,?,?,?,?)",
	                UUID.randomUUID().toString(), jersey.getSize().getId(), jersey.getBrand(), jersey.getClub(),
	                jersey.getYear(), jersey.getType().getId(), jersey.getCut().getId(), jersey.getMaterial().toString()) > 0;
		}
		return success;
	}
}
