package com.mastercard.codetest.jerseystore.exception;

public class JerseyException extends Exception {
	
	public JerseyException(String message) {
		super(message);
	}
	

}
