package com.mastercard.codetest.jerseystore.constants;

public class QueryConstant {
	
	public static final String GET_JERSEY = "SELECT * FROM JERSEY WHERE id = ?";
	
	public static final String ALL_JERSEY = "SELECT * FROM JERSEY";

}
