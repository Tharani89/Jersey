package com.mastercard.codetest.jerseystore.controller;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;

import com.mastercard.codetest.jerseystore.exception.JerseyException;
import com.mastercard.codetest.jerseystore.model.Jersey;
import com.mastercard.codetest.jerseystore.service.JerseyStoreService;

/**
 * Controller class
 * 
 * @author admin
 *
 */
@RestController
public class JerseyController {

	private static final Logger LOGGER = LoggerFactory.getLogger(JerseyController.class);

	private JerseyStoreService jerseyStoreService;

	@Autowired
	public JerseyController(JerseyStoreService jerseyStoreService) {
		this.jerseyStoreService = jerseyStoreService;
	}

	/**
	 * Method to get id of the Jersey values
	 * 
	 * @param id
	 *
	 */
	@GetMapping("/rest/api/v1/jersey/{id}")
	public Jersey getJersey(@PathVariable String id) throws Exception {
		LOGGER.info("Callling getJersey controller: " + id);
		return jerseyStoreService.getJersey(id);
	}

	@GetMapping("/rest/api/v1/jersey")
	public List<Jersey> getJerseys() {
		LOGGER.info("Callling getJerseys controller: ");
		List<Jersey> jerseyList = null;
		try {
			jerseyList = jerseyStoreService.getAllJerseys();
		} catch (Exception e) {
			e.printStackTrace();
		}
		return jerseyList;
	}

}
