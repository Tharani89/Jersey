-- BENFICA
insert into Jersey values ('0e113997-e9f4-4e6d-bb35-33a932fa83c5', 1, 'adidas', 'Benfica', '2017', 1, 1, 'COTTON');
insert into Jersey values ('d5029eb0-5ce9-4917-aa5d-471f24e7d298', 2, 'adidas', 'Benfica', '2017', 1, 1, 'NYLON');
insert into Jersey values ('53b2258e-78e6-4f28-95e7-642fe135971a', 3, 'adidas', 'Benfica', '2017', 1, 1, 'COTTON');
insert into Jersey values ('91da8f19-f064-4736-9f9a-722308c6e18c', 1, 'adidas', 'Benfica', '2017', 2, 1, 'NYLON');
insert into Jersey values ('e6e9007e-3bde-441c-bc23-4a7ad83b4ec8', 2, 'adidas', 'Benfica', '2017', 2, 1, 'COTTON');
insert into Jersey values ('60fe79f1-c4d7-45af-9043-4a2551dc6e52', 3, 'adidas', 'Benfica', '2017', 2, 1, 'NYLON');
insert into Jersey values ('f75e0048-5c6e-40fa-b1cf-24da3313304e', 1, 'adidas', 'Benfica', '2017', 1, 2, 'NYLON');
insert into Jersey values ('7641f804-c4d5-4012-95e9-f6492a41d033', 2, 'adidas', 'Benfica', '2017', 1, 2, 'COTTON');
insert into Jersey values ('236038cd-0b05-409e-9d21-04a63c984f35', 3, 'adidas', 'Benfica', '2017', 1, 2, 'NYLON');
insert into Jersey values ('911ec6e7-1a01-4d68-bc7b-fab436ae59b4', 1, 'adidas', 'Benfica', '2017', 2, 2, 'COTTON');
insert into Jersey values ('f7e831a6-7d7a-4441-a524-dacd10af7d09', 2, 'adidas', 'Benfica', '2017', 2, 2, 'NYLON');
insert into Jersey values ('67a62edb-61f2-4cef-87c9-89f40f98df7c', 3, 'adidas', 'Benfica', '2017', 2, 2, 'COTTON');
-- MANCHESTER UNITED
insert into Jersey values ('76afa32b-f02c-4beb-8639-2a4c24ea5611', 1, 'adidas', 'Man United', '2017', 1, 1, 'NYLON');
insert into Jersey values ('23f5973c-b700-403b-a056-4c0561d51265', 2, 'adidas', 'Man United', '2017', 1, 1, 'COTTON');
insert into Jersey values ('bc21b513-50de-45b0-9d8d-b31dd5d82078', 3, 'adidas', 'Man United', '2017', 1, 1, 'NYLON');
insert into Jersey values ('d7197699-370f-42d4-b1a0-f330631f3024', 1, 'adidas', 'Man United', '2017', 2, 1, 'COTTON');
insert into Jersey values ('ea3fdd8d-1570-44e7-93a2-5a63b1bdabf3', 2, 'adidas', 'Man United', '2017', 2, 1, 'NYLON');
insert into Jersey values ('fdafc144-62fc-4c68-8f4e-36793edfefcf', 3, 'adidas', 'Man United', '2017', 2, 1, 'COTTON');
insert into Jersey values ('cbac9531-e24d-4655-ba3f-ccf514786208', 1, 'adidas', 'Man United', '2017', 1, 2, 'COTTON');
insert into Jersey values ('b2bbd838-381b-4363-a646-c2ba2ec4de66', 2, 'adidas', 'Man United', '2017', 1, 2, 'COTTON');
insert into Jersey values ('8018c226-569a-4df5-b15e-99552dff7f95', 3, 'adidas', 'Man United', '2017', 1, 2, 'COTTON');
insert into Jersey values ('f6442b4f-0ba6-4dd4-a0ca-9637d7f8d0b0', 1, 'adidas', 'Man United', '2017', 2, 2, 'COTTON');
insert into Jersey values ('ca7a02f2-72da-4ee2-9bdb-499f2146e813', 2, 'adidas', 'Man United', '2017', 2, 2, 'COTTON');
insert into Jersey values ('9296a550-fdbc-49ca-85c0-169636434099', 3, 'adidas', 'Man United', '2017', 2, 2, 'COTTON');
-- REAL MADRID
insert into Jersey values ('d417434c-8e42-4433-9939-4d6e13e3a7df', 1, 'adidas', 'Real Madrid', '2017', 1, 1, 'COTTON');
insert into Jersey values ('a242550e-ed29-4b71-a7b1-d528b7e7d1eb', 2, 'adidas', 'Real Madrid', '2017', 1, 1, 'NYLON');
insert into Jersey values ('ce87ac40-7e86-47f9-9ee1-8e6e339596ac', 3, 'adidas', 'Real Madrid', '2017', 1, 1, 'COTTON');
insert into Jersey values ('3322c723-477e-4f31-9752-83b6dd9587b4', 1, 'adidas', 'Real Madrid', '2017', 2, 1, 'NYLON');
insert into Jersey values ('7c333a7c-6f47-4b7e-a5bc-2958948265c8', 2, 'adidas', 'Real Madrid', '2017', 2, 1, 'COTTON');
insert into Jersey values ('df6f30e2-906d-4b19-9379-6860782d58d3', 3, 'adidas', 'Real Madrid', '2017', 2, 1, 'NYLON');
insert into Jersey values ('834515e6-22b9-4f62-b123-97a4c6f82a98', 1, 'adidas', 'Real Madrid', '2017', 1, 2, 'COTTON');
insert into Jersey values ('c5c92d34-be12-40bb-b2c5-7e06bfe60c43', 2, 'adidas', 'Real Madrid', '2017', 1, 2, 'NYLON');
insert into Jersey values ('e823a566-626d-463c-98d9-4ad01b903f88', 3, 'adidas', 'Real Madrid', '2017', 1, 2, 'COTTON');
insert into Jersey values ('5045e274-695a-4efd-b9b3-e9ad4dccfdc7', 1, 'adidas', 'Real Madrid', '2017', 2, 2, 'NYLON');
insert into Jersey values ('e8da63a2-dfe5-4c1e-9728-cbbcbd11f950', 2, 'adidas', 'Real Madrid', '2017', 2, 2, 'COTTON');
insert into Jersey values ('7caa52d5-1959-437f-b384-1a5c88505a33', 3, 'adidas', 'Real Madrid', '2017', 2, 2, 'COTTON');
