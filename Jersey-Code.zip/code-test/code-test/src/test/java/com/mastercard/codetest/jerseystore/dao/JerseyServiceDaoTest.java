package com.mastercard.codetest.jerseystore.dao;

import static org.junit.Assert.*;

import java.util.Arrays;
import java.util.List;

import org.junit.BeforeClass;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Mockito;
import org.mockito.junit.MockitoJUnitRunner;
import org.springframework.jdbc.core.JdbcTemplate;

import com.mastercard.codetest.jerseystore.exception.JerseyException;
import com.mastercard.codetest.jerseystore.model.Jersey;
import com.mastercard.codetest.jerseystore.model.JerseyCut;
import com.mastercard.codetest.jerseystore.model.JerseyMaterial;
import com.mastercard.codetest.jerseystore.model.JerseySize;
import com.mastercard.codetest.jerseystore.model.JerseyType;

@RunWith(MockitoJUnitRunner.class)
public class JerseyServiceDaoTest {
	
	private static JerseyStoreDaoImpl mockJerseyDAO;
    private static Jersey jersey;

    @BeforeClass
    public static void init() throws JerseyException {
 
    	mockJerseyDAO = Mockito.mock(JerseyStoreDaoImpl.class);
    	Jersey jersey = getRequest();
        Mockito.when(mockJerseyDAO.getJersey("1")).thenReturn(jersey);
    }
 
    private static Jersey getRequest() {
       Jersey jersey = new Jersey();
       jersey.setId("0e113997-e9f4-4e6d-bb35-33a932fa83c5");
       jersey.setSize(JerseySize.valueOf(1));
       jersey.setBrand("adidas");
       jersey.setClub("Benfica");
       jersey.setCut(JerseyCut.valueOf(1));
       jersey.setMaterial(JerseyMaterial.value("COTTON"));
       jersey.setYear("2017");
       jersey.setType(JerseyType.valueOf(1));
       return jersey;
	}

	@Test
    public void getAllTest() throws JerseyException {
        Jersey jersey = mockJerseyDAO.getJersey("1");
        assertNotNull(jersey);
    }
 

}
